/*
enchant.nineleap.memory.LocalStorage.GAME_ID = 1283;
enchant.nineleap.memory.LocalStorage.DEBUG_MODE = true;
*/
var ctx;

enchant();

var Socket = function(msg){
  //msg.twitterID,msg.screen_name
  var addr = "http://182.163.60.121:8124";
  var userData = {twitterID:msg.twitterID,
                  screen_name:msg.screen_name};
  this.socket = io.connect(addr);
  this.socket.emit("join",userData);

  var that = this;
  this.socket.on("ready",function(msg){
    //2人揃った時に実行される
    alert("ready");
    that.server = io.connect(addr+"/"+msg.serverName);
    that.server.on("test",function(msg){
  //    alert(msg);
    });
    that.server.on("line",function(msg){
      canvas.enemyLine(msg.prev,msg.next);
    });
    that.server.on("score",function(msg){

    });
    that.server.on("time",function(msg){
 //     document.body.innerHTML += msg.time + "/";
    });
    that.server.on("end",function(msg){
   //   document.body.innerHTML += "END";
    });
  });
}
Socket.prototype.emit = function(type,msg){
  if(this.server == undefined){
    return;
  }
  this.server.emit(type,msg);
}

var Canvas = enchant.Class.create(enchant.Sprite,{
  initialize:function(){
    enchant.Sprite.call(this,320,320);
    this.surface = new Surface(320,320);
    this.image = this.surface;
    this.isConnectNetwork = false;
//scrarch!!　と書きこむ
    this.data = [];
    var ctx = this.surface.context;
    ctx.font = "52px 'ＭＳ Ｐゴシック'";
    ctx.fillStyle = "RGB(0,255,0)";
    var txt = "SCRATCH!!!";
    var metrics = ctx.measureText(txt);
    ctx.fillText(txt,160-metrics.width/2,110);
    txt = "擦れ！！！";
    metrics = ctx.measureText(txt);
    ctx.fillText(txt,160-metrics.width/2,210);

//残り時間のラベル
    this.restTimeLabel = new Label("20:00");
    this.restTimeLabel.time = 20.0;
    this.restTimeLabel.x = 280;
    this.restTimeLabel.y = 12;
    this.restTimeLabel.color = "RGB(255,0,0)";
    this.restTimeLabel._style.zIndex = 2;
    game.rootScene.addChild(this.restTimeLabel);

    var that = this;
    this.restTimeLabel.addEventListener("enterframe",function(){
      this.time-= 1/16;
      var txt = "";
      if(this.time < 10){
        txt += "0";
      }
      txt += this.time.toFixed(2);
      this.text = txt;
      if(this.time < 0){
        this.text = "00.00";
/*******************************
 *
        //ゲーム終了****************
                                      *
  ************************************/
        game.memory.player.data = that.data;
        game.memory.player.test = "test";
        game.memory.update();
        this.removeEventListener("enterframe",arguments.callee);
        alert("end");
      }
    });
    
    this.myColor = "RGB(0,0,0)";
    this.enemyColor = "RGB(255,0,0)";

    this.addEventListener("touchstart",function(e){
      this.prevX = e.x;
      this.prevY = e.y;
      this.penDown = true;
    });
    this.addEventListener("touchmove",function(e){
      if(!this.penDown)
        return ;
      var nextX = e.x;
      var nextY = e.y;   

      var prev = {x:this.prevX,y:this.prevY}; 
      var next = {x:nextX,y:nextY};
      this.myLine(prev,next);
      
      this.prevX = nextX;
      this.prevY = nextY;
    });
    this.addEventListener("touchend",function(e){
      this.penDown = false;
    });
  },
  myLine:function(prev,next){
    this.data.push(prev.x*1000+prev.y);
    this.line(prev,next,this.myColor);
    if(this.isConnectNetwork)
      socket.emit("line",{prev:prev,next:next});
  },
  enemyLine:function(prev,next){
    this.line(prev,next,this.enemyColor);
  },
  line:function(prev,next,color){
    var ctx = this.surface.context;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = "10";
    ctx.strokeStyle = color;
    ctx.beginPath();
    ctx.moveTo(prev.x,prev.y);
    ctx.lineTo(next.x,next.y);
    ctx.stroke();
  },
  addMyData:function(data){
    //自分用のラベル
    if(this.myLabel == undefined){
      this.myLabel = new Label("~MyData~ name:"+data.screen_name + 
                             ",rate:"+data.rank);
      this.myLabel.addEventListener("enterframe",function(){
        this.x -= 2;
        if(this.x <= -320){
          this.x = 320;
        }
      });
      game.rootScene.addChild(this.myLabel);
    }
    this.myLabel.y = 0;
    this.myLabel.x = 30;
    this.myLabel.font = "12px monospace";
    this.myLabel.color = "RGB(0,0,255)";
  },
  addEnemyData:function(data){
    //相手用のラベル
    if(this.enemyLabel == undefined){
      this.enemyLabel = new Label("~enemyData~ name:"+data.screen_name + 
                             ",rate:"+data.rank);
      this.enemyLabel.addEventListener("enterframe",function(){
        this.x -= 2;
        if(this.x <= -320){
          this.x = 320;
        }
      });
      game.rootScene.addChild(this.enemyLabel);

    }
    this.enemyLabel.y = 305;
    this.enemyLabel.x = 30;
    this.enemyLabel.font = "12px monospace";
    this.enemyLabel.color = "RGB(0,0,255)";
  },
  gameStart:function(){
    var scene = new Scene();
    game.pushScene(scene);
    var count = new Sprite(320,320);
    var overlay = new Sprite(320,320);

    var surface = new Surface(320,320);
    overlay.image = surface;

    scene.addChild(count);
    scene.addChild(overlay);

    var ctx = surface.context;
    ctx.fillStyle = "RGB(0,0,0)";
    var r;
    var theta = Math.PI*2/12;
    count.addEventListener("enterframe",function(){
      if(this.frame == 0){
        r = -3;
        this.image = game.assets["three.png"];
      }
      else if(this.frame == 16){
        r = -3;
        ctx.clearRect(0,0,320,320);
        this.image = game.assets["two.png"];
      }
      else if(this.frame == 32){
        r = -3;
        ctx.clearRect(0,0,320,320);
        this.image = game.assets["one.png"];
      }
      else if(this.frame == 48){
        game.popScene();
      }

      if(4 <= this.frame && this.frame < 16){
        ctx.beginPath();
        ctx.moveTo(160,160);
        ctx.arc(160,160,227,theta*r,theta*(r+1),false)
        ctx.closePath();
        ctx.fill();
        r++;
      }
      else if(20 <= this.frame && this.frame < 32){
        ctx.beginPath();
        ctx.moveTo(160,160);
        ctx.arc(160,160,227,theta*r,theta*(r+1),false);
        ctx.closePath();
        ctx.fill();
        r++;
      }
      else if(36 <= this.frame && this.frame < 48){
        ctx.beginPath();
        ctx.moveTo(160,160);
        ctx.arc(160,160,227,theta*r,theta*(r+1),false)
        ctx.closePath();
        ctx.fill();
        r++;
      }

      

      this.frame++;
    });

  } 
}
);

var socket;
var canvas;

window.onload = function() {
    game = new Game(320, 320);
    
    game.fps = 16;
    game.preload("three.png","two.png","one.png");
//    game.twitterRequest("account/verify_credentials");
    game.memory.player.preload();
    game.onload = function() {
     game.rootScene.addEventListener("enterframe",function(){
      });
      canvas = new Canvas();
      game.rootScene.addChild(canvas);
      game.rootScene.backgroundColor ="#eee";
/*
      var userData = game.twitterAssets['account/verify_credentials'][0];
      userData = {twitterID:userData.id_str,
                  screen_name:userData.screen_name};
  //    socket = new Socket(userData);
*/    
      canvas.addMyData({screen_name:"dangiruba",rank:"1500"});
      canvas.addEnemyData({screen_name:"dangiruba's ghost",rank:"0"});

      canvas.gameStart();
      

    };
    game.start();
};

