var io = require("socket.io").listen(8124)

var mysql = require("mysql");
var client = mysql.createClient({
  user:"rank_twitter",
  password:"aoh3o3FHOa",
  database:"rank"
});
/*
   client.query("SELECT * FROM rank",function(err,results){
   console.log(results);    
   });
   */
/* sanitize for SQL injection
   client.query(
   'INSERT INTO '+TEST_TABLE+' '+
   'SET title = ?, text = ?, created = ?',
   ['super cool', 'this is a nice text', '2010-08-16 10:00:23']
   );
   */

function getUserDataByTwitterId(twitterID,callback){
  client.query(
      "SELECT * FROM rank WHERE twitterID = ? or twitterID = ?;",
      twitterID,
      function(err,results){
        var ret = [];
        for(var i = 0; i < twitterID.length; i++){
          var j;
          var obj = new Object()
    for(j = 0; j < results.length; j++){
      if(twitterID[i] == results[j].twitterID){
        obj.twitterID = twitterID[i];
        obj.rank = results[j].rank;
        obj.screen_name = results[j].screen_name;
        break;
      }
    }
  if(j == results.length){
    obj.twitterID = "";
    obj.rank = "no_rate";
    obj.screen_name = "not login to twitter"
  }
  ret.push(obj);
        }
        callback(ret);
      }
  );
}

var Lobby = function(){
  this.waiting = [];
}
Lobby.prototype.join = function(socket,msg){
  if(msg.twitterID == ""){
    var userData = new Object();
    userData.twitterID = "";
    userData.rate = "no rate";
    userData.screen_name = "not login to twitter";
    this.push([socket,userData]);
  }
  else{
    client.query("SELECT * FROM rank WHERE twitterID = ?;",
      msg.twitterID,
      function(err,results){
        var userData = new Object()
        if(results.length == 0){
          //TODO:insert
          client.query("INSERT INTO rank(twitterID,screen_name,rank) " +
            "VALUES( ?, ?,1500);",
            [msg.twitterID,msg.screen_name],
            function(err,results){
              //TODO:ここちゃんと動くかわかんないから後で調べる
              //ていうかあとで書く。
              //this.push([socket,userData]);
            }
          );
        }
        else{
          userData.twitterID = results[0].twitterID;
          userData.rank = results[0].rank;
          userData.screen_name = results[0].screen_name;
          this.push([socket,userData]);
        }
      }
   );
  }
}
Lobby.prototype.push = function(obj){
  this.waiting.push(obj);
  this.match();
}
Lobby.prototype.match = function(){
  //人数がn人以下になるまでマッチし続ける
  var n = 2;
  while(this.waiting.length >= n){
    var p = [];
    for(var i = 0; i < n; i++){
      var p[i] = this.waiting.shift();
    }
    var msgForP = [];
    for(var i = 0; i < p.length; i++){
      msgForP[i] = new Object();
      msgForP[i].me = p[i];
      msgForP[i].other = []
      for(var j = 0; j < p.length; j++){
        if(j != i){
          msgForP[i].other.push(p[j]);
        }
      }
    }
    for(var i = 0; i < p.length; i++){
      p[i].emit("ready",msgForP[i]);
    }
  }
}

var lobby = new Lobby();
lobby.join("socket",{
  twitterID:"102122",
})
lobby.join("socket",{
  twitterID:"102124",
})

io.sockets.on("connection",function(socket){
  //ユーザが接続してきたら実行される
  console.log(socket);
  socket.on("joinChannel",function(msg){
    console.log("joined");
  });
  socket.on("message",function(msg){
    socket.broadcast.emit("message",{msg:"msg"});
    console.log(msg);
  });

  socket.on("disconnect",function(){
    //クライアントが切断された時実行
  });

});

