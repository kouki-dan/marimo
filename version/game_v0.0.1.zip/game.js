enchant();

window.onload = function() {
    var game = new Game(320, 320);
    game.fps = 24;
    game.preload();

    game.socket = new Socket();
    game.socket.lobby.join();

    game.socket.gameRoom.addEventListener('ready',function(data){
      console.log(data);
    });

    game.onload = function() {
      var surface = new Surface(320,320);
      
    };
    game.start();
};
